#include "device_config/config_parser.h"
#include "device_config/device_type.h"
#include "device_config/nvm_items.h"
#include "device_config/reset.h"
#include "hal/nvm.h"
#include "hal/printf_selector.h"
#include "hal/system.h"
#include "hal/zigbee.h"
#include "tuya_bridge/bridge_app.h"
#include "tuya_bridge/bridge8_app.h"
#include "zigbee/basic_cluster.h"
#include "hal/zigbee_ota.h"
#include "zigbee/battery_cluster.h"
#include "zigbee/general_commands.h"
#ifdef END_DEVICE
#include "zigbee/poll_control_cluster.h"
#endif

void process_device_type_change() {
    // If device was updated from router to end device or vice versa,
    // we need to do a reset, as the network settings stored by SDK in NVM
    // are not compatible between these device types.
    // Read device type from NVM and compare with current configuration.
    enum device_type_t stored_device_type;
    hal_nvm_status_t   st =
        hal_nvm_read(NV_ITEM_DEVICE_TYPE, sizeof(stored_device_type),
                     (uint8_t *)&stored_device_type);

    if (st != HAL_NVM_SUCCESS) {
        // Unable to read device type from NVM, possibly first boot.
        stored_device_type = CURRENT_DEVICE_TYPE;
        hal_nvm_write(NV_ITEM_DEVICE_TYPE, sizeof(stored_device_type),
                      (uint8_t *)&stored_device_type);
        return;
    }
    if (stored_device_type != CURRENT_DEVICE_TYPE) {
        printf("Device type change detected: %d -> %d\r\n", stored_device_type,
               CURRENT_DEVICE_TYPE);
        // Device type has changed, update NVM and reset device.
        stored_device_type = CURRENT_DEVICE_TYPE;
        hal_nvm_write(NV_ITEM_DEVICE_TYPE, sizeof(stored_device_type),
                      (uint8_t *)&stored_device_type);
        // Perform a factory reset to clear incompatible network settings.
        hal_factory_reset();
        schedule_reboot(2000);
    }
}

void app_init(void) {
    handle_version_changes();
    parse_config();

    {
        // Modo ponte Tuya: ativado quando o modelo termina em -BR
        // (basic_cluster.modelId e pascal-string: [0]=len, [1..]=texto)
        extern zigbee_basic_cluster basic_cluster;
        uint8_t L = basic_cluster.modelId[0];
        const char *mm = (const char *)&basic_cluster.modelId[1];
        if (L >= 3 && mm[L-3] == '-' && mm[L-2] == 'B' && mm[L-1] == 'R') {
            bridge_app_init();
        }
        if (L >= 3 && mm[L-3] == '-' && mm[L-2] == 'R' && mm[L-1] == 'D') {
            radar_app_init();
        }
        if (L >= 3 && mm[L-3] == '-' && mm[L-2] == 'B' && mm[L-1] == '8') {
            bridge8_app_init();
        }
    } // Does most of the setup, including all callbacks
                    // registration
    hal_zigbee_init_ota();
    init_global_attr_write_callback();

    process_device_type_change();
}

static bool boot_announce_sent = false;

void app_task() {
#ifdef END_DEVICE
    poll_control_cluster_update();
#endif

    // TODO: add jitter to avoid all devices trying to join at once
    if (hal_zigbee_get_network_status() != HAL_ZIGBEE_NETWORK_JOINED &&
        hal_zigbee_get_network_status() != HAL_ZIGBEE_NETWORK_JOINING) {
        hal_zigbee_start_network_steering();
    }
    if (!boot_announce_sent &&
        hal_zigbee_get_network_status() == HAL_ZIGBEE_NETWORK_JOINED) {
        hal_zigbee_send_announce();
        boot_announce_sent = true;
    }
}
