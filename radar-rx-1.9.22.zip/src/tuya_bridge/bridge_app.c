#include "bridge_app.h"
#include <stdint.h>
#include "bridge_core.h"
#include "hal/uart.h"
#include "hal/tasks.h"
#include "hal/printf_selector.h"
#include "zigbee/relay_cluster.h"
#include "zigbee/switch_cluster.h"
#include "zigbee/basic_cluster.h"
#include "hal/system.h"

// ============================================================
// ConnectCasa tuya_mcu_bridge - aplicacao da ponte
// Painel 3ch+3cenas (_TZE284_3kjidznp) - mapa DP confirmado:
//   Reles:  DP 24/25/26  <-> relay_clusters[0..2]
//   Botoes: DP 4/5/6 (0=simples,1=duplo,2=segurar) -> actions teclas 1..3
//   Cenas:  DP 1/2/3 (canal em modo cena) -> action single da tecla
//   Backlight: DP 36 (on/off), DP 101 (brilho 0-99)
// ============================================================

#define DP_RELAY_1      24
#define DP_RELAY_2      25
#define DP_RELAY_3      26
#define DP_CENA_MIN     1
#define DP_CENA_MAX     6
// Mapa REAL medido em campo (o stock nasceu deslocado +1!):
#define DP_BTN_1        5
#define DP_BTN_2        6
#define DP_BTN_3        7
#define DP_SCENE_CH_1   1
#define DP_SCENE_CH_2   2
#define DP_SCENE_CH_3   3
#define DP_MODE_CH_1    18
#define DP_MODE_CH_2    19
#define DP_MODE_CH_3    20
#define DP_BACKLIGHT    36
#define DP_BRIGHTNESS   101

// Valores multistate (mesma tabela do switch_cluster/converters)
#define MS_LONG_PRESS   2
#define MS_SINGLE       5
#define MS_DOUBLE       6
#define MS_TRIPLE       7
#define MS_CENA_BASE    11  // 11/12/13 = cena single/double/triple

extern zigbee_relay_cluster relay_clusters[];
extern zigbee_switch_cluster switch_clusters[];

static uint8_t g_active = 0;
static uint8_t g_suppress_dp_tx = 0;  // evita eco DP<->cluster

static hal_task_t g_tick_task;

// Auto-baud: cicla as velocidades Tuya ate o handshake fechar
static const uint32_t BAUDS[] = {115200, 9600}; // spec: 115200 fixo
static uint8_t g_baud_idx = 0;
static uint16_t g_ticks_in_state = 0;
#define BAUD_SWITCH_TICKS 40   // 4s sem handshake -> proxima velocidade

static void on_mcu_dp(const tuya_dp_t *dp);
const char *bridge_dp_log(void);

static void uart_rx(const uint8_t *bytes, uint16_t len) {
    bridge_rx(bytes, len);
    // ACKs nao podem esperar o tick de 100ms: a MCU tem timeout curto.
    // Reagenda o tick para JA (drena a fila em ~1ms, fora da IRQ).
    hal_tasks_schedule(&g_tick_task, 1);
}

static void bridge_uart_tx(const uint8_t *bytes, uint16_t len) {
    hal_uart_send(bytes, len);
}

static void tick(void *arg) {
    hal_uart_process();
    bridge_tick_100ms();

    // Auto-baud: sem operacao apos 4s, tenta a proxima velocidade
    if (bridge_state() != BR_ST_OPERATIONAL) {
        g_ticks_in_state++;
        if (g_ticks_in_state >= BAUD_SWITCH_TICKS) {
            g_ticks_in_state = 0;
            g_baud_idx = (g_baud_idx + 1) % 2;
            printf("bridge: auto-baud -> %d\r\n", (int)BAUDS[g_baud_idx]);
            hal_uart_init(BAUDS[g_baud_idx], uart_rx);
            bridge_init(bridge_uart_tx, on_mcu_dp);
        }
    } else {
        g_ticks_in_state = 0;
    }

    basic_cluster_update_bridge_hidden(bridge_rx_frame_count(),
                                       bridge_dp_log());
    hal_tasks_schedule(&g_tick_task, 100);
}

static hal_task_t g_action_reset_task;
static uint8_t g_action_pending[3] = {0, 0, 0};

static void action_reset(void *arg) {
    for (uint8_t i = 0; i < 3; i++) {
        if (g_action_pending[i]) {
            g_action_pending[i] = 0;
            switch_cluster_emit_action(&switch_clusters[i], 0);
        }
    }
}

static uint8_t ritual_armed(void);
static void emit_action(uint8_t key_idx, uint8_t ms_value);

// ===== Multiclique fabricado na ponte (a MCU so manda toques v=0) =====
#define MC_WINDOW_MS 400
static uint8_t g_mc_count[6];
static hal_task_t g_mc_task[6];

static void mc_fire(void *arg) {
    uint8_t src = (uint8_t)(uintptr_t)arg;
    uint8_t n = g_mc_count[src];
    g_mc_count[src] = 0;
    if (n == 0) return;
    if (n > 3) n = 3;
    // Valor unico por tecla+gesto: 11 + src*3 + (n-1) => 11..28
    uint8_t key = src % 3;
    uint8_t value = 11 + src * 3 + (n - 1);
    emit_action(key, value);
}

static void emit_action(uint8_t key_idx, uint8_t ms_value);

static void mc_press_v(uint8_t src, uint8_t mcu_val) {
    if (src > 5) return;
    if (mcu_val != 0) {
        // A MCU JA classificou (0=single,1=double,2=hold): emite direto.
        // gesto n: 1=single,2=double,3=hold -> valor 11+src*3+(n-1)
        uint8_t n = mcu_val + 1;   // 1->double(2), 2->hold(3)
        if (n > 3) n = 3;
        uint8_t key = src % 3;
        emit_action(key, 11 + src * 3 + (n - 1));
        return;
    }
    // v==0: multiclique fabricado por contagem
    g_mc_count[src]++;
    g_mc_task[src].handler = mc_fire;
    g_mc_task[src].arg = (void *)(uintptr_t)src;
    hal_tasks_init(&g_mc_task[src]);
    hal_tasks_schedule(&g_mc_task[src], MC_WINDOW_MS);
}

static void emit_action(uint8_t key_idx, uint8_t ms_value) {
    if (key_idx > 2) return;
    if (ms_value == MS_LONG_PRESS && ritual_armed()) {
        printf("bridge: RITUAL por gesto - factory wipe\r\n");
        basic_cluster_request_factory_wipe();
        return;
    }
    switch_cluster_emit_action(&switch_clusters[key_idx], ms_value);
    g_action_pending[key_idx] = 1;
    g_action_reset_task.handler = action_reset;
    hal_tasks_init(&g_action_reset_task);
    hal_tasks_schedule(&g_action_reset_task, 400);
}

static void set_relay_from_dp(uint8_t idx, uint8_t on) {
    if (idx > 2) return;
    g_suppress_dp_tx = 1;
    if (on) relay_cluster_on(&relay_clusters[idx]);
    else    relay_cluster_off(&relay_clusters[idx]);
    g_suppress_dp_tx = 0;
}

// Ritual de reset fisico: 7 toques rapidos + segurar (0x03 da MCU)
#define RITUAL_PRESSES   7
#define RITUAL_WINDOW_MS 8000
static uint32_t g_press_times[RITUAL_PRESSES];
static uint8_t g_press_idx = 0;

static void ritual_note_press(void) {
    g_press_times[g_press_idx % RITUAL_PRESSES] = hal_millis();
    g_press_idx++;
}

static uint8_t ritual_armed(void) {
    if (g_press_idx < RITUAL_PRESSES) return 0;
    uint32_t now = hal_millis();
    for (uint8_t i = 0; i < RITUAL_PRESSES; i++) {
        if (now - g_press_times[i] > RITUAL_WINDOW_MS + 6000) return 0;
    }
    return 1;
}

void bridge_on_mcu_reset_request(void) {
    if (ritual_armed()) {
        printf("bridge: RITUAL completo - factory wipe\r\n");
        basic_cluster_request_factory_wipe();
    }
}

// ===== Gravador de DP para cacar o hold =====
static char g_dp_log[64];
static uint16_t g_dp_log_pos = 0;

static void dp_log_add(const tuya_dp_t *dp) {
    static const char H[] = "0123456789ABCDEF";
    // SO grava DPs de tecla (1..7). Ignora backlight(36/101), modos(18-20),
    // relés(24-26) — o ruido automatico que apagava o registro do gesto.
    if (dp->id > 7) return;
    if (g_dp_log_pos > 48) g_dp_log_pos = 0;
    uint8_t val = dp->len > 0 ? dp->data[dp->len - 1] : 0;
    uint8_t trio[3] = {dp->id, dp->type, val};
    for (uint8_t i = 0; i < 3; i++) {
        g_dp_log[g_dp_log_pos++] = H[trio[i] >> 4];
        g_dp_log[g_dp_log_pos++] = H[trio[i] & 0xF];
        g_dp_log[g_dp_log_pos++] = (i < 2) ? '.' : ' ';
    }
    g_dp_log[g_dp_log_pos] = 0;
}

const char *bridge_dp_log(void) { return g_dp_log; }

static void on_mcu_dp(const tuya_dp_t *dp) {
    uint8_t v = dp->len > 0 ? dp->data[dp->len - 1] : 0;
    dp_log_add(dp);
    if (dp->id == 1 || dp->id == 2 || dp->id == 3 ||
        dp->id == 5 || dp->id == 6 || dp->id == 7) {
        ritual_note_press();
    }
    switch (dp->id) {
    case DP_RELAY_1: set_relay_from_dp(0, v); break;
    case DP_RELAY_2: set_relay_from_dp(1, v); break;
    case DP_RELAY_3: set_relay_from_dp(2, v); break;
    // Mapa real: esquerda=DP1,2,3  direita=DP5,6,7 (pula o 4)
    case 1: mc_press_v(0, v); break;
    case 2: mc_press_v(1, v); break;
    case 3: mc_press_v(2, v); break;
    case 5: mc_press_v(3, v); break;
    case 6: mc_press_v(4, v); break;
    case 7: mc_press_v(5, v); break;
    case DP_BACKLIGHT:
        basic_cluster_update_bridge_backlight(v ? 1 : 0);
        break;
    case DP_BRIGHTNESS:
        basic_cluster_update_bridge_brightness(v);
        break;
    case DP_MODE_CH_1:
    case DP_MODE_CH_2:
    case DP_MODE_CH_3:
        basic_cluster_update_bridge_mode(dp->id - DP_MODE_CH_1, v);
        break;
    default:
        bridge_note_unknown_dp(dp->id, v);
        printf("bridge: DP %d desconhecido (type %d len %d)\r\n",
               dp->id, dp->type, dp->len);
        break;
    }
}

// Chamado pelo relay_cluster quando o rele muda (comando Zigbee/binding)
void bridge_on_relay_change(uint8_t relay_index, uint8_t state) {
    if (!g_active || g_suppress_dp_tx) return;
    if (relay_index > 2) return;
    bridge_set_dp_bool(DP_RELAY_1 + relay_index, state ? 1 : 0);
}

uint8_t bridge_app_active(void) { return g_active; }

// ===== Modo RADAR (modelo -RD): descoberta de fiacao =====
static hal_task_t g_radar_task;
static void radar_tick(void *arg) {
    radar_step();
    // Expoe: frames_rx = status (bit7=achou, bits0-6=tx_idx atual),
    //        ultimo_frame (hex) = resultado (tx_idx<<8 | rx_idx)
    extern unsigned char radar_status(void);
    extern unsigned short radar_result(void);
    static char hex[8];
    static const char H[] = "0123456789ABCDEF";
    unsigned short r = radar_result();
    hex[0]=H[(r>>12)&0xF]; hex[1]=H[(r>>8)&0xF];
    hex[2]=H[(r>>4)&0xF]; hex[3]=H[r&0xF]; hex[4]=0;
    basic_cluster_update_bridge_hidden(radar_status(), hex);
    hal_tasks_schedule(&g_radar_task, 3000);
}

static hal_task_t g_radarx_task;
static void radarx_tick(void *arg) {
    void radar_rx_step(void);
    unsigned char radar_rx_best_pin(void);
    unsigned short radar_rx_best_edges(void);
    radar_rx_step();
    // expoe: frames_rx = indice do melhor pino; ultimo_frame(hex) = bordas
    static char hex[8]; static const char H[]="0123456789ABCDEF";
    unsigned short e = radar_rx_best_edges();
    hex[0]=H[(e>>12)&0xF]; hex[1]=H[(e>>8)&0xF];
    hex[2]=H[(e>>4)&0xF]; hex[3]=H[e&0xF]; hex[4]=0;
    basic_cluster_update_bridge_hidden(radar_rx_best_pin(), hex);
    hal_tasks_schedule(&g_radarx_task, 2000);
}
void radar_rx_app_init(void) {
    g_radarx_task.handler = radarx_tick;
    g_radarx_task.arg = 0;
    hal_tasks_init(&g_radarx_task);
    hal_tasks_schedule(&g_radarx_task, 3000);
    printf("RADAR-RX: escuta passiva iniciada\r\n");
}

void radar_app_init(void) {
    g_radar_task.handler = radar_tick;
    g_radar_task.arg = 0;
    hal_tasks_init(&g_radar_task);
    hal_tasks_schedule(&g_radar_task, 5000);
    printf("RADAR: varredura de UART iniciada\r\n");
}

void bridge_ui_backlight(uint8_t on) {
    if (g_active) bridge_set_dp_bool(DP_BACKLIGHT, on);
}
void bridge_ui_brightness(uint8_t pct) {
    if (g_active) bridge_set_dp_value(DP_BRIGHTNESS, pct);
}
void bridge_ui_mode(uint8_t ch, uint8_t mode) {
    if (g_active && ch < 3) bridge_set_dp_enum(DP_MODE_CH_1 + ch, mode);
}

void bridge_app_init(void) {
    g_active = 1;
    hal_uart_init(9600, uart_rx);
    bridge_init(bridge_uart_tx, on_mcu_dp);
    g_tick_task.handler = tick;
    g_tick_task.arg = 0;
    hal_tasks_init(&g_tick_task);
    hal_tasks_schedule(&g_tick_task, 100);
    printf("bridge_app: iniciado (UART 9600, mapa 3ch+3cenas)\r\n");
}
